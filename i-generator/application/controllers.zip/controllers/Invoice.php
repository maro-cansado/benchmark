<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Invoice extends CI_Controller {

	function __construct()
	{
	       	parent::__construct();

	       	//load helper
			$this->load->helper('url');

			//load libraries
			$this->load->library('algosecure');
			$this->load->library('session');

			//load model
			$this->load->model('user_m');
			$this->load->model('settings_m');

			//load template
			$this->check_if_login();
			$this->output->set_template('dashboard/template');
	}

	function check_if_login()
	{
		$user_id = $this->session->userdata('id');
		if(isset($user_id))
		{
			$user_id = $this->algosecure->decrypt($user_id);
			$result = $this->user_m->getUserById($user_id);

			if(sizeof($result) < 1)
			{
				redirect('login');
			}

		}else
		{
			redirect('login');
		}
	}

	public function view()
	{
		$entry = json_decode($_POST['invouce-entry-json']);
		$user_id = $this->algosecure->decrypt($_POST['adviser-id']);

		$user = $this->user_m->getUserById($user_id);
		
		$computed_result = $this->invoice_calcu($user_id,$entry);

		$this->load->library('Pdf', array('company'=> null, 'fspr'=>"FSPR"));
		

		 $this->pdf->company = 'asdasd';
      	$this->pdf->fspr_number = '1231';
      	$this->pdf->SetTitle('title');

      	$this->data['computed_result'] = $computed_result;
       	$this->data['user'] = $user;
		$this->data['active_parent'] = 'invoice';

      	$this->load->view('invoice/buyer_created_tax_invoice_test',$this->data);
  //     	$html = $this->load->view('invoice/buyer_created_tax_invoice',$this->data, true);
		// $this->pdf->AddPage(); // add a page
  //       $this->pdf->writeHTMLCell(0,0, 12, 5, $html, 0, 0, false, true, '', true);


  //       $actual_file = "disclosure.pdf";
  //       $this->pdf->Output($actual_file, 'I');
	}

	public function invoice_calcu($user_id,$entry)
	{
		// set percent
		$wt_percent = 0.20;
		$am_percent = 0.10;

		$user = $this->user_m->getUserById($user_id);
		$user_settings = $this->settings_m->getUserSettings($user_id);
		
		$bcti = array();
		$bcan = array();

		foreach ($entry as $index => $e) {
			if($e[4] == "BCTI")
			{
				array_push($bcti, $entry[$index]);
			}else
			{
				array_push($bcan, $entry[$index]);
			}
		}

		// compute BCTI
		$bcti_debit = $this->compute_bcti_debit($bcti);
		$bcti_credit = $this->compute_bcti_credit($bcti);
		$bcti_gst = $this->compute_gst($bcti_debit+$bcti_credit,$user_settings[0]['gst'],$user_settings[0]['gst_age_percent']);

		// compute BCAN
		$bcan_debit = $this->compute_bcan_debit($bcan);
		$bcan_credit = $this->compute_bcan_credit($bcan);
		$bcan_gst = $this->compute_gst($bcan_debit+$bcan_credit,$user_settings[0]['gst'],$user_settings[0]['gst_age_percent']);

		//compute nett
		$total_nett = ($bcti_debit + $bcan_debit) + ($bcti_credit + $bcan_credit);

		//compute total gst
		if($user_settings[0]['gst'])
		{
			$total_gst = $total_nett * ($user_settings[0]['gst_age_percent']/100);
		}else
		{
			$total_gst = 0;
		}

		//compute Withholding Tax
		$total_wt = ($total_nett * $wt_percent) * -1;

		//compute agency movement
		$agency_movement = ((($total_nett + $total_gst) - ($total_wt * -1)) * $am_percent) * -1;

		//compute total
		$total = (($total_nett + $total_gst) + $agency_movement) + $total_wt;

		$result = array(
			'bcti' => array(
				'item' => $bcti,
				'bcti_debit' => $bcti_debit,
				'bcti_credit' => $bcti_credit,
				'bcti_gst' => $bcti_gst,
			), 
			'bcan' => array(
				'item' => $bcan,
				'bcan_debit' => $bcan_debit,
				'bcan_credit' => $bcan_credit,
				'bcan_gst' => $bcan_gst,
			), 
			'total_nett' => $total_nett, 
			'total_gst' => $total_gst, 
			'total_wt' => $total_wt, 
			'agency_movement' => $agency_movement, 
			'total' => $total, 
		);

		return $result;
	}

	public function compute_bcti_debit($bcti)
	{
		$debit_result = 0;
		foreach ($bcti as $index => $debit) {
			$debit_result += floatval($debit[2]);
		}

		return $debit_result;
	}

	public function compute_bcti_credit($bcti)
	{
		$credit_result = 0;
		foreach ($bcti as $index => $credit) {
			$credit_result += floatval($credit[3]);
		}

		return $credit_result;
	}


	public function compute_bcan_debit($bcan)
	{
		$debit_result = 0;
		foreach ($bcan as $index => $debit) {
			$debit_result += floatval($debit[2]);
		}

		return $debit_result;
	}

	public function compute_bcan_credit($bcan)
	{
		$credit_result = 0;
		foreach ($bcan as $index => $credit) {
			$credit_result += floatval($credit[3]);
		}

		return $credit_result;
	}

	public function compute_gst($sum,$gst,$per)
	{
		if($gst)
		{
			return $sum * ($per/100);
		}else
		{
			return 0;
		}
	}
	 
}
