<style>
	.container-header{
		width:100%;
		text-align:center;
		height: 500px;
		color:#074B8D;font-weight:400;font-size:15px;
	}
	.font-color-payment-header{
		font-weight: bold;
		font-size: 8px;
	}
</style>

<div class="container-header" ><br/><br/>
	Buyer Created Tax Invoice
</div><br/><br/>
<table width="100%" style="padding:5px;" >
	<tr style="background-color:#E1E1E1;">
		<td width="20%"  ><b>Adviser No: <?= $user[0]['id'] ?></b></td>
		<td width="55%" ><b>Name of Adviser: <?= $user[0]['first_name'] ?> <?= $user[0]['last_name'] ?></b></td>
		<td width="25%" ><b>Period of : <?= date("m/d/Y"); ?></b></td>
	</tr>
</table><br/><br/>
<table>
	<tr>
		<td width="65">
			Produced On:
		</td>
		<td width="220">
			<?= date("m/d/Y", strtotime($user[0]['createdAt'])); ?><br/><br/>
			
		</td>
		<td width="80">
			Produced By:<br/>
			Combined Insurance A division of ACE Insurance Limited Private Bag COMBINED Remuera Auckland 1541
		</td>
		<td width="77">
			Statement Week:<br/>
			Statement Date:<br/>
			Payment Type:<br/>
			Termination Date:<br/>
			IRD:
		</td>
		<td width="70">
			201526<br/>
			29/06/2015<br/>
			Direct Credit<br/><br/>
			86071600<br/>
		</td>
	</tr>
</table>
<table style="">
	<tr>
		<td width="420" ></td>
		<td><br/>
			<span style="color:#FF0000;font-weight:bold;font-size:9px;" >Payment Amount</span>
		</td>
	</tr>
	<tr>
		<td width="415" style="border-bottom:1px solid #D0D0D0;" ></td>
		<td width="95" style="border-bottom:1px solid #D0D0D0;" ><br/>
			<div style="border:2px solid #808080;text-align:center;color:#FF003F;font-size:10px;font-weight:bold;"><br/>$4,960.54<br/></div>
		</td>
	</tr>
</table> 
<p style="font-size:10px;" ><b>Buyer Created Tax Invoice</b></p>
<table style="postion:relative;left:-2px;border:1px solid #ddd;">
	<tr style="border:1px solid #ddd;background-color:#E1E1E1;">
		<td>
			<span><br/>
			Date
			</span><br/>
		</td>
		<td>
			<span><br/>
				Description
			</span><br/>
		</td>
		<td>
			<span><br/>
				Debit
			</span><br/>
		</td>
		<td>
			<span><br/>
				Credit
			</span><br/>
		</td>
		<td>
			<span><br/>
				GST
			</span><br/>
		</td>
	</tr>
	<tr style="" >
		<td>
			<span style="font-size:9px;" >
				22/06/2015
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				Weekly Production
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				$1,340.92
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
	</tr>
	<tr style="" >
		<td>
			<span style="font-size:9px;" >
				22/06/2015
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				Renewal Commission
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				$1,340.92
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
	</tr>
	<tr style="" >
		<td>
			<span style="font-size:9px;" >
				06/07/2015
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				Bonuses
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				$1,340.92
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
	</tr>
	<tr style="" >
		<td>
			<span style="font-size:9px;" >
				22/06/2015
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				Overrides
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				$1,340.92
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
	</tr>

	<tr>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				$0.00
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				$5,996.39
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				$899.46
			</span><br/>
		</td>
	</tr>
	
</table>

<p style="font-size:10px;" ><b>Buyer Created Tax Invoice</b></p>
<table style="postion:relative;left:-2px;border:1px solid #ddd;">
	<tr style="border:1px solid #ddd;background-color:#E1E1E1;">
		<td>
			<span><br/>
			Date
			</span><br/>
		</td>
		<td>
			<span><br/>
				Description
			</span><br/>
		</td>
		<td>
			<span><br/>
				Debit
			</span><br/>
		</td>
		<td>
			<span><br/>
				Credit
			</span><br/>
		</td>
		<td>
			<span><br/>
				GST
			</span><br/>
		</td>
	</tr>
	<tr style="" >
		<td>
			<span style="font-size:9px;" >
				22/06/2015
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				Cancellations
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				$-754.76
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
	</tr>
	<tr style="" >
		<td>
			<span style="font-size:9px;" >
				22/06/2015
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				Material Fee & Lap Top
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				$-20.00
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
		<td>
			<span style="font-size:9px;" >
				
			</span>
		</td>
	</tr>

	<tr>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				$-774.76
				
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				$0.00
			</span><br/>
		</td>
		<td style="border-top:1px sold #ddd;" >
			<span style="font-size:9px;" ><br/>
				$-116.21
			</span><br/>
		</td>
	</tr>
	
</table>
<p></p>
<table>
	<tr>
		<td>
		</td>
		<td>
			<b>Totals</b>
		</td>
		<td>
			<b>$-774.76</b>
		</td>
		<td>
			<b>$5,996.39</b>
		</td>
		<td>
			<b>Nett</b>
		</td>
		<td>
			<b>$5,221.63</b>
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			
		</td>
		<td>
			
		</td>
		<td>
			
		</td>
		<td>
			<b>Nett</b>
		</td>
		<td>
			<b>$5,221.63</b>
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			
		</td>
		<td>
			
		</td>
		<td>
			
		</td>
		<td>
			<b>Nett</b>
		</td>
		<td>
			<b>$5,221.63</b>
		</td>
	</tr>
	<tr>
		<td>
		</td>
		<td>
			
		</td>
		<td>
			
		</td>
		<td>
			
		</td>
		<td>
			<b>Nett</b>
		</td>
		<td>
			<b>$5,221.63</b>
		</td>
	</tr>

</table>

