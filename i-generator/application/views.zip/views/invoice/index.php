  <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Invoice
        <!-- <small>Blank example to the fixed layout</small> -->
      </h1>
      <!-- <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Layout</a></li>
        <li class="active">Fixed</li>
      </ol> -->
    </section>

    <!-- Main content -->
    <section class="content">

     <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Buyer Created Tax Invoice & Buyer Created Adjustment Note</h3>

         
        </div>
        <form method="POST" action="<?= base_url(); ?>index.php/invoice/view" target="_blank" >
        <input type="hidden" value="" id="invouce-entry-json" name="invouce-entry-json" value="" >
        <div class="box-body" >
          <div class="row" >
            <div class="col-md-12">
              <div class="form-group">
                <label>Select Adviser To Invoice: </label>
                <select class="form-control" id="adviser-id" name="adviser-id" >
                  <?php foreach ($users as $index => $user) { ?>
                    <option value="<?= $this->algosecure->encrypt($user['id']); ?>" ><?= $user['last_name'].', '.$user['first_name'].' '.$user['middle_name'] ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="box-body no-padding">
              <table class="table table-striped">
                <tbody id="tbody-entry">

                  <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Debit</th>
                    <th>Credit</th>
                    <th>type</th>
                    <th></th>
                  </tr>



                </tbody>
              </table>
            </div>
        </div>

        <div class="box-body" style="margin-top:100px;" >
          <div class="row" >
            <div class="col-md-2">
              <div class="form-group">
                <label>Date:</label>

                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input class="form-control pull-right datepicker" type="text" id="add-entry-date" name="add-entry-date" >
                </div>
                <!-- /.input group -->
              </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                  <label for="add-entry-description">Description</label>
                  <input class="form-control" id="add-entry-description" name="add-entry-description" placeholder="Description" type="text">
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Debit</label>
                  <input class="form-control" id="add-entry-debit" name="add-entry-debit" placeholder="Description" type="text">
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                  <label for="exampleInputEmail1">Credit</label>
                  <input class="form-control" id="add-entry-credit" name="add-entry-credit" placeholder="Description" type="text">
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                  <label>Type</label>
                  <select class="form-control" id="add-entry-type" name="add-entry-type" >
                    <option value="BCTI" >BCTI</option>
                    <option value="BCAN" >BCAN</option>
                  </select>
                </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">
            <div class="form-group" style="margin-left:10px;" >
              <button type="button" class="btn btn-primary" id="btn-add-entry" >Add Entry</button>
            </div>
          </div>
          
        </div>
        <div class="row">
          <div class="col-md-12 ">
             
            <div class="form-group" style="margin-right:10px;" >
              <button type="button" class="btn btn-success pull-right" id="btn-generate-invoice" >Generate Invoice</button>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-12 ">
             <div class="form-group" style="margin-right:10px;margin-top:5px;" >
              <button type="submit" class="btn btn-default pull-right" id="btn-generate-invoice" style="width:127px;" >Preview Invoice</button>
            </div>
            
          </div>
        </div>

        </form>
        <!-- /.box-body -->
       <br/>
      </div>
      

      <!-- <div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Invoice Generator</h3>

         
        </div> -->
        <!-- /.box-header -->
        <!-- <div class="box-body">
          
        </div> -->
        <!-- /.box-body -->
       
     <!--  </div> -->
      

    </section>
    <!-- /.content -->