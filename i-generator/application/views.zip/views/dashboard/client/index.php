<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    Client
    <small>this is a users in this system</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?= base_url(); ?>index.php/dashboard/client">Client</a></li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
 <!--  <div class="callout callout-info">
    <h4>Tip!</h4>

    <p>Add the fixed class to the body tag to get this layout. The fixed layout is your best option if your sidebar
      is bigger than your content because it prevents extra unwanted scrolling.</p>
  </div> -->
  <div class="row">
        <div class="col-xs-12">
          <a href="<?= base_url() ?>dashboard/add_client" class="btn btn-primary pull-right">+ Add Client</a>
        </div>
        <div class="col-xs-12">

          <div class="box">

            <div class="box-header">
             <!--  <h3 class="box-title">Hover Data Table</h3> -->
            </div>
            <!-- /.box-header -->

            <div class="box-body">

              <table id="client-table" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Client Name</th>
                  <th>Email</th>
                  <th>Date of Birth</th>
                  <th>Created At</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php foreach ($users as $index => $user) { ?>
                    <tr>
                      <td><?= $user['first_name'].' '.$user['middle_name'].' '.$user['last_name'] ?></td>
                      <td><?= $user['email'] ?></td>
                      <td><?= date("F jS, Y", strtotime($user['date_of_birth'])); ?></td>
                      <td><?= date("F jS, Y", strtotime($user['createdAt'])); ?></td>
                      <td>
                        <a href="<?= base_url(); ?>index.php/dashboard/edit_client/<?= $this->algosecure->encrypt($user['id']); ?>" class="btn btn-success" >Edit</a>
                        <a href="javascript:delete_client('<?= $this->algosecure->encrypt($user['id']); ?>');" class="btn btn-danger" >Delete</a>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Client Name</th>
                  <th>Email</th>
                  <th>Date of Birth</th>
                  <th>Created At</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>

</section>

<div class="modal modal-danger" id="modal-delete-client">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close btn-close-delete-client" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span></button>
        <h4 class="modal-title">Delete Client</h4>
      </div>
      <div class="modal-body">
        <p>Delete this client ?</p>
      </div>
      <div class="modal-footer">
       
        <button type="button" class="btn btn-outline btn-close-delete-client pull-left" data-dismiss="modal">Close</button>
         <form method="POST" action="<?= base_url(); ?>index.php/users/delete_client" >
          <input type="hidden" id="delete-client-id" name="delete-client-id" value="" >
          <button type="submit" class="btn btn-outline">Delete Client</button>
        </form>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
