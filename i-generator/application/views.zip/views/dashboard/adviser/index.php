<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    Adviser
    <small>this is a users in this system</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?= base_url(); ?>index.php/dashboard/adviser">Adviser</a></li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
 <!--  <div class="callout callout-info">
    <h4>Tip!</h4>

    <p>Add the fixed class to the body tag to get this layout. The fixed layout is your best option if your sidebar
      is bigger than your content because it prevents extra unwanted scrolling.</p>
  </div> -->
  <div class="row">
        <div class="col-xs-12">
          <a href="<?= base_url() ?>dashboard/add_adviser" class="btn btn-primary pull-right">+ Add adviser</a>
        </div>
        <div class="col-xs-12">

          <div class="box">

            <div class="box-header">
              <!-- <h3 class="box-title">Hover Data Table</h3> -->
            </div>
            <!-- /.box-header -->

            <div class="box-body">

              <table id="agency-table" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>adviser Name</th>
                  <th>Email</th>
                  <th>Date of Birth</th>
                  <th>Created At</th>
                  
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                  <?php $user_dummy_id = 0; ?>
                  <?php foreach ($users as $index => $user) { ?>
                    <tr>
                      <td><?= $user['first_name'].' '.$user['middle_name'].' '.$user['last_name'] ?></td>
                      <td><?= $user['email'] ?></td>
                      <td><?= date("F jS, Y", strtotime($user['date_of_birth'])); ?></td>
                      <td><?= date("F jS, Y", strtotime($user['createdAt'])); ?></td>
                      
                      <td>
                        <a href="<?= base_url(); ?>index.php/dashboard/edit_adviser/<?= $this->algosecure->encrypt($user['id']); ?>" class="btn btn-success" >Edit</a>
                        <a href="javascript:delete_adviser('<?= $this->algosecure->encrypt($user['id']); ?>');" class="btn btn-danger" >Delete</a>
                        
                      </td>
                    </tr>
                    <?php $user_dummy_id++; ?>
                  <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>adviser Name</th>
                  <th>Email</th>
                  <th>Date of Birth</th>
                  <th>Created At</th>
                  
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>

</section>

<div class="modal modal-danger" id="modal-delete-adviser">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close btn-close-delete-adviser" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span></button>
        <h4 class="modal-title">Delete Adviser</h4>
      </div>
      <div class="modal-body">
        <p>Delete this adviser ?</p>
      </div>
      <div class="modal-footer">
       
        <button type="button" class="btn btn-outline btn-close-delete-adviser pull-left" data-dismiss="modal">Close</button>
         <form method="POST" action="<?= base_url(); ?>index.php/users/delete_adviser" >
          <input type="hidden" id="delete-adviser-id" name="delete-adviser-id" value="" >
          <button type="submit" class="btn btn-outline">Delete Adviser</button>
        </form>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
