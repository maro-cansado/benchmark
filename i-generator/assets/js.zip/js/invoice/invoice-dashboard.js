$(document).ready(function(){
	$('.datepicker').datepicker({
      autoclose: true
    });

    $("#btn-add-entry").click(function(){
    	var date = $("#add-entry-date").val();
    	var description = $("#add-entry-description").val();
    	var debit = $("#add-entry-debit").val()==""? 0:$("#add-entry-debit").val();
        var credit = $("#add-entry-credit").val()==""? 0:$("#add-entry-credit").val();
    	var type = $("#add-entry-type").val();

    	var json = $("#invouce-entry-json").val();
    	console.log(json);
    	if(json != "")
    	{
    		json = $.parseJSON(json);

    		data = [date,description,debit,credit,type];

    		json.push(data);
    	}else
    	{
    		json = [];

    		data = [date,description,debit,credit,type];

    		json.push(data);


    	}

    	var data_tr = $('<tr></tr>');
    	var td_date = $('<td>'+date+'</td>');
    	var td_description = $('<td>'+description+'</td>');
    	var td_debit = $('<td>'+debit+'</td>');
        var td_credit = $('<td>'+credit+'</td>');
    	var td_type = $('<td>'+type+'</td>');
    	var td_btn = $('<td><button class="btn btn-danger" type="button" onclick="delete_entry(this)" >+</button></td>');

    	data_tr.append(td_date);
    	data_tr.append(td_description);
    	data_tr.append(td_debit);
        data_tr.append(td_credit);
    	data_tr.append(td_type);
    	data_tr.append(td_btn);

    	$("#tbody-entry").append(data_tr);

    	json = JSON.stringify(json);
    	$("#invouce-entry-json").val(json);

    });
});

function delete_entry(btn)
{
    $(btn).parent().parent().remove();

    json = [];
    var count = $("#tbody-entry").find('tr').length;
    $("#tbody-entry").find('tr').each(function(index){
       if(index == 0)
       {
            $("#invouce-entry-json").val('');
       }else
       {
            var date = $( "#tbody-entry" ).find('tr:eq('+index+')').find('td:eq(0)').html();
            var description = $( "#tbody-entry" ).find('tr:eq('+index+')').find('td:eq(1)').html();
            var debit = $( "#tbody-entry" ).find('tr:eq('+index+')').find('td:eq(2)').html();
            var credit = $( "#tbody-entry" ).find('tr:eq('+index+')').find('td:eq(3)').html();
            var type = $( "#tbody-entry" ).find('tr:eq('+index+')').find('td:eq(4)').html();

            data = [date,description,debit,credit,type];

            json.push(data);
       }

       if(! --count)
       {
        json = JSON.stringify(json);
        $("#invouce-entry-json").val(json);
       }
    });
    
}